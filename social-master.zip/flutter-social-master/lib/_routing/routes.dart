const String landingViewRoute = '/';

const String loginViewRoute = 'login';
const String registerViewRoute = 'register';
const String resetPasswordViewRoute = 'reset_password';

const String homeViewRoute = 'home';
const String chatDetailsViewRoute = 'chat_details';
const String userDetailsViewRoute = 'user_details';